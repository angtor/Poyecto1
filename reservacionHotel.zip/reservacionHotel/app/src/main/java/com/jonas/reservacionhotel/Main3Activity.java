package com.jonas.reservacionhotel;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main3Activity extends AppCompatActivity {
    EditText nombre,apellidos,idPersona,tel,correo;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        nombre = (EditText) findViewById(R.id.nombre);
        apellidos = (EditText) findViewById(R.id.apellidos);
        idPersona = (EditText) findViewById(R.id.idPersona);
        tel = (EditText) findViewById(R.id.tel);
        correo = (EditText) findViewById(R.id.correo);
        boton = (Button) findViewById(R.id.boton);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mandarMail();
            }
        });

    }
    private void mandarMail(){
        Intent email = new Intent(Intent.ACTION_SEND);
        email.setData(Uri.parse("mailto: "));
        email.setType("text/plain");
        email.putExtra(Intent.EXTRA_SUBJECT,nombre.getText());
        email.putExtra(Intent.EXTRA_SUBJECT,apellidos.getText());
        email.putExtra(Intent.EXTRA_SUBJECT,idPersona.getText());
        email.putExtra(Intent.EXTRA_SUBJECT,tel.getText());
        email.putExtra(Intent.EXTRA_EMAIL,correo.getText());

        startActivity(Intent.createChooser(email,"Send Email:"));
    }
}
